export interface IPrint {
    print(): void;
}


