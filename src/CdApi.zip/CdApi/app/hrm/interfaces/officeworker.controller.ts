import { EmployeeBase } from './employee.abstruct'
export class OfficeWorker /* extends  EmployeeBase */ {
    doWork() {
        // console.log(`${this.name} : doing work`);
    }
}