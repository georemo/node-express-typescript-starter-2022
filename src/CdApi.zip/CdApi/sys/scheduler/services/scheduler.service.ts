export class SchedulerService{
    getCalendarSumm(cuid){
        return [{}];
    }

}