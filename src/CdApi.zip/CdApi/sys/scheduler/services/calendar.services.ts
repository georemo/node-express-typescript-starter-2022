export class CalendarService{
    getCalendarSumm(cuid){
        return [{}];
    }
}