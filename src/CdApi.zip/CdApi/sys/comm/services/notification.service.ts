export class NotificationService{
    getsrvNotifications(cuid){
        return [{}];
    }

    getsrvNotifications_summary(cuid){
        return [{}];
    }
}