export class MemoService{
    getMemoSummary(cuid){
        return [{}];
    }
}