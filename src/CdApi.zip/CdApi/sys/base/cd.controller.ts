

export abstract class CdController {
    svx: any;
}