export default {
    register: {
        notification: {
            email: false,
            socketIo: false,
            webPush: false
        }
    }
}